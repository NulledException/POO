public class Cachorro extends Animal{
	
	public String late() {
		return this.getNome() + " latindo!";
	}

}
